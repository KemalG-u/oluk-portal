
Hey there! Thanks for downloading my Spiritual Yoga — Icon Pack

This icon pack contains 36 Spiritual Yoga icons, designed using a grid and a customizable stroke weight for all your creative project needs.

**Includes**
- 36 Spiritual Yoga Icons
- PNG, EPS, SVG, PDF, and AI
- Various Sized Exports
- Illustrator Source File Included
- Stoked and Expanded Files

**Spiritual Yoga Icons**
- Buddha
- Yoga Mat
- Lotus
- Floating Guru
- Online Booking
- Yoga
- Yoga App
- Mindfulness
- Female Meditate
- Yoga Pose
- Yoga Date
- Group Meditation
- Hindu
- Candles
- Outdoor Yoga
- Hot Yoga
- Male Meditate
- Water Bottle
- Yoga Strap
- Burning Incense
- Heart Centre
- Balance Balls
- Yoga Time
- Yoga Mats
- Enlightenment
- Oil Burner
- Indoor Yoga
- Video Lessons
- Hot Stones
- Hot Oils
- Svadhishthana
- Vishuddha
- Anahata
- Manipura
- Muladhara
- Sahasrara