INTRODUCING
Icons with various styles by kreevstudio. Perfect for your mobile apps website and presentations

FILES INCLUDED:
- PNG
- SVG
- FIG

Download more icons at :
https://elements.envato.com/user/kreevstudio