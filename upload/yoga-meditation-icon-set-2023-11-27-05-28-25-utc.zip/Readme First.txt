Yoga & Meditation Icon Set

This design will great to icon
Specification

300 DPI Resolution
Ai, EPS, SVG, PNG
Editable Color Style
Well Organized Layer

if you want to ask something or ask for a license, 
you can contact us via email : pitchlook.agen@gmail.com

I hope you like it :)